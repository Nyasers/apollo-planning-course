import json
import unittest
from pathlib import Path

from apollo_claw.scenario_checks import build_scenario_rule
from apollo_claw.scoring import compute_self_score, threshold_score


class SelfScoreTest(unittest.TestCase):
    def test_threshold_score_is_linear(self):
        self.assertEqual(threshold_score(3.0, 3.0), 100.0)
        self.assertEqual(threshold_score(6.0, 3.0), 0.0)
        self.assertEqual(threshold_score(4.5, 3.0), 50.0)

    def test_perfect_metrics_and_comfort_score_100(self):
        score = {
            "metrics": [
                {"name": "SpeedLimit", "pass": True, "score": 100},
                {"name": "ReachEnd", "pass": True, "score": 100},
            ]
        }
        metrics = {
            "max_lon_accel": 1.0,
            "max_jerk": 1.0,
            "max_lat_accel": 1.0,
            "hard_brake": 0,
        }
        result = compute_self_score(score, metrics, scenario_pass=True)
        self.assertEqual(result["value"], 100.0)
        self.assertEqual(result["performance_score"], 100.0)
        self.assertEqual(result["comfort_score"], 100.0)
        self.assertTrue(result["gate_passed"])
        self.assertFalse(result["is_official"])

    def test_critical_failure_forces_zero(self):
        score = {"metrics": [{"name": "Collision", "pass": False, "score": 100}]}
        result = compute_self_score(score, {"max_jerk": 1.0}, scenario_pass=True)
        self.assertEqual(result["value"], 0.0)
        self.assertEqual(result["gate_status"], "FAIL")
        self.assertEqual(result["critical_failures"], ["Collision"])

    def test_without_comfort_uses_performance_score(self):
        score = {"metrics": [{"name": "SpeedLimit", "pass": True, "score": 90}]}
        result = compute_self_score(score, {}, scenario_pass=True)
        self.assertEqual(result["value"], 90.0)
        self.assertIsNone(result["comfort_score"])


    def test_crosswalk_distance_failure_deducts_twenty(self):
        score = {
            "metrics": [{"name": "SpeedLimit", "pass": True, "score": 100}],
            "crosswalk_stop_distance": {
                "distance_m": 2.096,
                "raw_map_distance_m": 3.026,
                "min_m": 1.5,
                "max_m": 2.0,
                "pass": False,
            },
        }
        metrics = {
            "max_lon_accel": 1.0,
            "max_jerk": 1.0,
            "max_lat_accel": 1.0,
            "hard_brake": 0,
        }
        result = compute_self_score(score, metrics, scenario_pass=True)
        self.assertEqual(result["value"], 80.0)
        self.assertEqual(result["scenario_penalty"], 20.0)
        self.assertEqual(result["scenario_gate_status"], "FAIL")
        self.assertFalse(result["scenario_rule"]["pass"])

    def test_crosswalk_distance_pass_keeps_full_score(self):
        score = {
            "metrics": [{"name": "SpeedLimit", "pass": True, "score": 100}],
            "crosswalk_stop_distance": {
                "distance_m": 1.8,
                "min_m": 1.5,
                "max_m": 2.0,
                "pass": True,
            },
        }
        result = compute_self_score(score, {}, scenario_pass=True)
        self.assertEqual(result["value"], 100.0)
        self.assertEqual(result["scenario_penalty"], 0.0)
        self.assertEqual(result["scenario_gate_status"], "PASS")
    def test_traffic_light_incomplete_without_signal(self):
        rule = build_scenario_rule("traffic-light", {"has_signal": False})
        self.assertEqual(rule["status"], "INCOMPLETE")
        self.assertFalse(rule["gate_fail_zero"])

    def test_traffic_light_distance_outside_range_deducts_fifty(self):
        rule = build_scenario_rule("traffic-light", {
            "has_signal": True,
            "red_frames": 30,
            "red_stop_duration_s": 5.0,
            "stop_line_gap_median_m": 2.2,
        })
        self.assertEqual(rule["status"], "DEDUCT")
        self.assertEqual(rule["penalty"], 50.0)
        self.assertEqual(rule["min_m"], 1.5)
        self.assertEqual(rule["max_m"], 2.0)

    def test_traffic_light_over_line_is_zero_gate(self):
        rule = build_scenario_rule("traffic-light", {
            "has_signal": True,
            "red_frames": 30,
            "red_stop_duration_s": 5.0,
            "stop_line_gap_median_m": -0.2,
        })
        self.assertEqual(rule["status"], "FAIL_ZERO")
        self.assertTrue(rule["gate_fail_zero"])

    def test_traffic_light_deducted_rule_changes_final_score(self):
        rule = build_scenario_rule("traffic-light", {
            "has_signal": True,
            "red_frames": 30,
            "red_stop_duration_s": 5.0,
            "stop_line_gap_median_m": 2.2,
        })
        result = compute_self_score(
            {"metrics": [{"name": "SpeedLimit", "pass": True, "score": 100}]},
            {"max_lon_accel": 1.0, "max_jerk": 1.0, "max_lat_accel": 1.0, "hard_brake": 0},
            scenario_pass=True,
            scenario_rule=rule,
        )
        self.assertEqual(result["value"], 50.0)
        self.assertEqual(result["score_status"], "DEDUCTED")
    def test_competition_scenario_assets_are_packaged(self):
        root = Path(__file__).resolve().parents[1] / "apollo_claw" / "defaults"
        scenario = json.loads((root / "xh_2026_obstacle_stop.scenario.json").read_text(encoding="utf-8"))
        official = json.loads((root / "xh_2026_obstacle_stop.official-grading.json").read_text(encoding="utf-8"))
        self.assertIn("障碍物停车避让", scenario["descriptionEnTokens"][0])
        self.assertEqual(official["gradingInfo"]["score"], 100)
        self.assertEqual(official["gradingInfo"]["status"], "finish_pass")
if __name__ == "__main__":
    unittest.main()

