"""Scenario-specific pass/fail rules layered on top of generic metrics."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

DEFAULT_CONFIG = Path(__file__).resolve().parent / "defaults" / "scenario_checks.json"


def _number(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def load_scenario_config(task_id: str) -> Optional[Dict[str, Any]]:
    try:
        data = json.loads(DEFAULT_CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    rule = (data.get("scenarios") or {}).get(task_id)
    return rule if isinstance(rule, dict) else None


def build_scenario_rule(task_id: str, signal_light: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return the traffic-light scenario rule, or None for other tasks."""
    if task_id != "traffic-light":
        return None
    config = load_scenario_config("traffic-light") or {}
    data = signal_light or {}
    has_signal = bool(data.get("has_signal"))
    red_frames = int(data.get("red_frames") or data.get("color_frames", {}).get("RED", 0) or 0)
    red_stop_duration = _number(data.get("red_stop_duration_s"))
    gap = _number(data.get("stop_line_gap_median_m"))
    if gap is None:
        gap = _number(data.get("stop_line_gap_m"))
    min_m = _number(config.get("min_m")) or 1.5
    max_m = _number(config.get("max_m")) or 2.0
    penalty = _number(config.get("penalty")) or 50.0
    min_red_stop = _number(config.get("min_red_stop_s")) or 1.0
    base = {
        "id": "traffic_light_stop",
        "label": config.get("label", "红绿灯停车规则"),
        "short_label": config.get("short_label", "红绿灯场景分"),
        "distance_m": gap,
        "stop_line_gap_m": gap,
        "min_m": min_m,
        "max_m": max_m,
        "red_frames": red_frames,
        "red_stop_duration_s": red_stop_duration,
        "has_signal": has_signal,
        "penalty": 0.0,
        "gate_fail_zero": False,
        "source": "planning.debug.planning_data.signal_light",
    }
    if not has_signal or red_frames <= 0:
        base.update({
            "status": "INCOMPLETE",
            "message": "record 未包含红灯信号数据，无法判断红绿灯停车规则。",
        })
        return base
    if red_stop_duration is None or red_stop_duration < min_red_stop:
        base.update({
            "status": "FAIL_ZERO",
            "gate_fail_zero": True,
            "message": f"红灯期间停车不足 {min_red_stop:g} 秒。",
        })
        return base
    if gap is None:
        base.update({
            "status": "INCOMPLETE",
            "message": "检测到红灯，但没有可用停止线距离数据。",
        })
        return base
    if gap < 0:
        base.update({
            "status": "FAIL_ZERO",
            "gate_fail_zero": True,
            "message": f"车头越过停止线，实测距离 {gap:.3f} m。",
        })
        return base
    if gap < min_m or gap > max_m:
        base.update({
            "status": "DEDUCT",
            "penalty": penalty,
            "message": f"停车距离 {gap:.3f} m，不在 {min_m:g}—{max_m:g} m 内，扣 {penalty:g} 分。",
        })
        return base
    base.update({
        "status": "PASS",
        "message": f"红灯停车距离 {gap:.3f} m，符合 {min_m:g}—{max_m:g} m。",
    })
    return base
