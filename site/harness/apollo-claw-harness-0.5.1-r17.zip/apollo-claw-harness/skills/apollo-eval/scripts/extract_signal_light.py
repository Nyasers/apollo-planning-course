#!/usr/bin/env python3
"""Extract traffic-light stop metrics from an Apollo planning record.

The script is intended to run inside the Apollo container, where
``cyber_py3`` and the Apollo-generated protobuf modules are available.
"""
import argparse
import json
import statistics
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    sys.stdout.reconfigure(errors="replace")
except AttributeError:
    pass

try:
    from cyber_record.record import Record
except ImportError:
    sys.path.insert(0, "/opt/apollo/neo/python")
    try:
        from cyber.python.cyber_py3 import record as _cyber
    except ImportError:
        print("[ERROR] cyber_py3 is unavailable; run this script inside the Apollo container.", file=sys.stderr)
        raise SystemExit(2)

    class Record:
        def __init__(self, path: str):
            self._reader = _cyber.RecordReader(str(path))

        def read_messages(self):
            for item in self._reader.read_messages():
                topic = getattr(item, "topic", item[0])
                payload = getattr(item, "message", item[1])
                timestamp = getattr(item, "timestamp", item[2] if len(item) > 2 else 0)
                if hasattr(payload, "SerializeToString"):
                    payload = payload.SerializeToString()
                yield topic, payload, timestamp

try:
    from modules.common_msgs.planning_msgs.planning_pb2 import ADCTrajectory
except ImportError:
    ADCTrajectory = None

COLOR_NAMES = {
    0: "UNKNOWN",
    1: "RED",
    2: "YELLOW",
    3: "GREEN",
    4: "BLACK",
}
PLANNING_CHANNEL = "/apollo/planning"
STOP_SPEED_MPS = 0.2
MIN_STOP_SECONDS = 1.0


def _number(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _color_name(value: Any) -> str:
    try:
        return COLOR_NAMES.get(int(value), "UNKNOWN")
    except (TypeError, ValueError):
        return "UNKNOWN"


def _choose_signal(signal_light: Any) -> Optional[Dict[str, Any]]:
    candidates = []
    for item in getattr(signal_light, "signal", []):
        stop_s = _number(getattr(item, "light_stop_s", None))
        front_s = _number(getattr(signal_light, "adc_front_s", None))
        if stop_s is None or front_s is None:
            continue
        gap = stop_s - front_s
        candidates.append({
            "light_id": str(getattr(item, "light_id", "") or ""),
            "color": _color_name(getattr(item, "color", 0)),
            "light_stop_s": stop_s,
            "adc_front_s": front_s,
            "stop_line_gap_m": gap,
            "adc_stop_deceleration": _number(getattr(item, "adc_stop_deceleration", None)),
        })
    if not candidates:
        return None
    # The nearest upcoming light is the one relevant to the stop decision.
    return min(candidates, key=lambda item: abs(item["stop_line_gap_m"]))


def _read_frames(record_path: str) -> List[Dict[str, Any]]:
    if ADCTrajectory is None:
        raise RuntimeError("planning protobuf is unavailable")
    record = Record(record_path)
    frames: List[Dict[str, Any]] = []
    for topic, payload, timestamp_ns in record.read_messages():
        if topic != PLANNING_CHANNEL:
            continue
        message = ADCTrajectory()
        message.ParseFromString(payload)
        header_time = _number(getattr(message.header, "timestamp_sec", None))
        timestamp = header_time if header_time is not None else float(timestamp_ns) / 1e9
        signal_light = message.debug.planning_data.signal_light
        selected = _choose_signal(signal_light)
        frames.append({
            "timestamp": timestamp,
            "speed_mps": _number(getattr(signal_light, "adc_speed", None)),
            "adc_front_s": _number(getattr(signal_light, "adc_front_s", None)),
            "has_signal": selected is not None,
            "light_id": selected["light_id"] if selected else "",
            "color": selected["color"] if selected else "UNKNOWN",
            "stop_line_gap_m": selected["stop_line_gap_m"] if selected else None,
            "adc_stop_deceleration": selected["adc_stop_deceleration"] if selected else None,
        })
    frames.sort(key=lambda item: item["timestamp"])
    return frames


def _red_overlap_seconds(event_frames: List[Dict[str, Any]]) -> float:
    red = 0.0
    for current, following in zip(event_frames, event_frames[1:]):
        dt = max(0.0, float(following["timestamp"]) - float(current["timestamp"]))
        if current.get("color") == "RED":
            red += dt
    return round(red, 3)


def _collect_stop_events(frames: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    events: List[Dict[str, Any]] = []
    current: List[Dict[str, Any]] = []
    def flush():
        nonlocal current
        if not current:
            return
        duration = round(float(current[-1]["timestamp"]) - float(current[0]["timestamp"]), 3)
        if duration >= MIN_STOP_SECONDS:
            red_frames = [frame for frame in current if frame.get("color") == "RED"]
            gaps = [float(frame["stop_line_gap_m"]) for frame in current if frame.get("stop_line_gap_m") is not None]
            selected_gaps = [float(frame["stop_line_gap_m"]) for frame in red_frames if frame.get("stop_line_gap_m") is not None] or gaps
            event = {
                "start_s": round(float(current[0]["timestamp"]), 3),
                "end_s": round(float(current[-1]["timestamp"]), 3),
                "duration_s": duration,
                "red_stop_duration_s": _red_overlap_seconds(current),
                "light_id": current[-1].get("light_id", ""),
                "colors": sorted({frame.get("color", "UNKNOWN") for frame in current}),
                "stop_line_gap_min_m": round(min(selected_gaps), 3) if selected_gaps else None,
                "stop_line_gap_max_m": round(max(selected_gaps), 3) if selected_gaps else None,
                "stop_line_gap_m": round(selected_gaps[-1], 3) if selected_gaps else None,
                "stop_line_gap_median_m": round(statistics.median(selected_gaps), 3) if selected_gaps else None,
            }
            events.append(event)
        current = []

    for frame in frames:
        speed = _number(frame.get("speed_mps"))
        if speed is not None and speed < STOP_SPEED_MPS:
            current.append(frame)
        else:
            flush()
    flush()
    return events


def extract(record_path: str) -> Dict[str, Any]:
    frames = _read_frames(record_path)
    signal_frames = [frame for frame in frames if frame.get("has_signal")]
    colors: Dict[str, int] = {name: 0 for name in COLOR_NAMES.values()}
    for frame in signal_frames:
        colors[frame.get("color", "UNKNOWN")] = colors.get(frame.get("color", "UNKNOWN"), 0) + 1
    events = _collect_stop_events(frames)
    eligible = [event for event in events if event.get("red_stop_duration_s", 0) > 0]
    selected = max(eligible, key=lambda item: item["red_stop_duration_s"]) if eligible else None
    return {
        "record_path": record_path,
        "has_signal": bool(signal_frames),
        "planning_frames": len(frames),
        "signal_frames": len(signal_frames),
        "color_frames": colors,
        "stop_events": events,
        "red_frames": colors.get("RED", 0),
        "stop_line_gap_m": selected.get("stop_line_gap_m") if selected else None,
        "stop_line_gap_median_m": selected.get("stop_line_gap_median_m") if selected else None,
        "stop_duration_s": selected.get("duration_s") if selected else None,
        "red_stop_duration_s": selected.get("red_stop_duration_s") if selected else None,
        "selected_light_id": selected.get("light_id") if selected else "",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract traffic-light stop metrics from Apollo planning record")
    parser.add_argument("record", help="cyber record path")
    parser.add_argument("--json", dest="json_path", help="write output JSON to this path")
    args = parser.parse_args()
    try:
        result = extract(args.record)
    except Exception as exc:
        print(f"[ERROR] signal-light extraction failed: {exc}", file=sys.stderr)
        return 1
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.json_path:
        Path(args.json_path).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json_path).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

